package il.ac.hit.Networking.ChatSystem;

/**
 * Created by shay on 03/08/2014.
 */
public interface StringConsumer {
    public void consume(String str);
}